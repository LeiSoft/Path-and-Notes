/**
 * @author hepengju
 *
 */
@A_Anno // 包上注解
package com.hepengju.java05.new07_annotation;