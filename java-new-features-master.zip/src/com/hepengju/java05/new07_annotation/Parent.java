package com.hepengju.java05.new07_annotation;

/**
 * 父类, 用于演示继承注解
 * 
 * @author hepengju
 *
 */
@P1_Anno
@P2_Anno
public class Parent {

}
