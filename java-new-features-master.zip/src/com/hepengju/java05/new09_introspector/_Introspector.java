package com.hepengju.java05.new09_introspector;

/**
 * 
 * 内省(introspector)
 * 
 * <pre>
 *  TODO
 * </pre>
 * 
 * @author hepengju
 *
 */
public class _Introspector {

}
