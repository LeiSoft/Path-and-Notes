package com.hepengju.java05.new05_enum;

/**
 * 颜色枚举: 最简单的枚举
 * 
 * @author hepengju
 *
 */
public enum ColorEnum {
    RED,BLUE,GREEN
}