package com.hepengju.java05.new08_juc;

/**
 * 
 * java.util.concurrent: 在并发编程中很常用的实用工具类
 * 
 * <pre>
 *  TODO
 * </pre>
 * 
 * @see 尚硅谷JUC视频教程  链接: https://pan.baidu.com/s/1brYNssetziG6RzdgUDUyxQ 提取码: 1tei 
 * 
 * @author hepengju
 *
 */
public class _JUC {

}
