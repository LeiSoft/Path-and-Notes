package com.hepengju.java05.new06_generic;

public class PersonGeneric extends Generic<Person>{

    public PersonGeneric(Person key) {
        super(key);
    }

}
