package com.hepengju.java05.new06_generic;

/**
 * 泛型信息的反射获取
 * 
 * <br> TODO
 * <br> 疑问: 为什么泛型信息在编译后的class文件中已经被擦除了,还能通过反射获得泛型信息呢? (难道是编译成class前的阶段就获得了?)
 * <br>
 * <br>
 * <br>
 * 
 * @author hepengju
 *
 */
public class _GenericReflect {

}
