package com.hepengju.java05.new06_generic;

/**
 * 子类指定泛型实现
 * 
 * @author hepengju
 *
 */
public class StringGenerator extends Generic<String>{

    public StringGenerator(String key) {
        super(key);
    }

}
