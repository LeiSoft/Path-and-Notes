package com.hepengju.java17.new03_sealedclass;


/**
 * 密封类和接口(正式)
 *
 * @see com.hepengju.java15.new01_sealedclass._SealedClass
 */
public class _SealedClass {}
