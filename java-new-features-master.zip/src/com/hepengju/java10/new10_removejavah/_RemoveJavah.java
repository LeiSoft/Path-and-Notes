package com.hepengju.java10.new10_removejavah;

/**
 * 
 * 删除工具javah
 * 
 * <pre>
 *     JEP 313: Remove the Native-Header Generation Tool 
 *     从JDK中移除了javah工具，这个很简单并且很重要。
 *     @See <a href="http://openjdk.java.net/jeps/313">
 * </pre>
 * 
 * @author WGR
 *
 */
public class _RemoveJavah {

}

