package com.hepengju.java10.new08_ca;

/**
 * 根证书颁发认证（CA）
 * 
 * <pre>
 * 
 *  这将使OpenJDK对开发人员更具吸引力，它还旨在减少OpenJDK和Oracle JDK构建之间的差异。
 *  附：暂时未在网上找到相关资料。
 *  
 * </pre>
 * 
 * @author WGR
 *
 */
public class _new08_ca {

}
