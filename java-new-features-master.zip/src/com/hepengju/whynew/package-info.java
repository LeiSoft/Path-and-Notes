/**
 * 
 * Java新特性的引入示例
 * 
 * @author hepengju
 *
 */
package com.hepengju.whynew;