package com.hepengju.java09.new09_jsonAPI;

/**
 * 轻量级JSON API
 * 
 * 一个标准化和轻量级的JSON API被许多java开发人员所青睐。但是由于资金问题无法在Java 9中见到。
 * 
 * @author WGR
 *
 */
public class _JsonAPI {

}
