package com.hepengju.java09.new01_jigsaw.module_02;

import com.hepengju.java09.new01_jigsaw.module_01._Person;

/**
 * 对模块化进行测试
 * 
 * @author WGR
 *
 */
public class _Module {
    
    public void testModule() {
        
        _Person p = new _Person("Tom",12);
        System.out.println(p);
        
    }

}
