package com.hepengju.java08.new05_optional;

/**
 * 保险
 * 
 * @author hepengju
 *
 */
public class Insurance {

    private String name;
    
    public Insurance(String name) {
        super();
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
}
