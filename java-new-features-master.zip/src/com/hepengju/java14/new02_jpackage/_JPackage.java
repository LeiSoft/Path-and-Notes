package com.hepengju.java14.new02_jpackage;

/**
 * jpackage 打包工具
 *
 * @see <a href="https://openjdk.java.net/jeps/392">打包工具</a>
 */
public class _JPackage {
}
