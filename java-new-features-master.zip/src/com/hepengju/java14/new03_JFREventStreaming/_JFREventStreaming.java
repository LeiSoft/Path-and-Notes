package com.hepengju.java14.new03_JFREventStreaming;

public class _JFREventStreaming {
}
